module.exports = function(grunt) {
    grunt.initConfig({
        less: {
            development: {
                options: {
                    compress: false
                },
                files: {
                    "css/main.css": "styles/main.less"
                }
            }
        },

        watch: {
            less: {
                files: ['styles/**/**/*.less'],
                tasks: ['less', 'autoprefixer']
            }
        },

        uglify: {
            options: {
                beautify: false
            },
            my_target: {
                files: {
                    'scripts/new/main.js': [
                        'scripts/lib/jquery-2.1.1.min.js',
                        'scripts/module.js'
                    ]
                }
            }
        },
        autoprefixer: {
            no_dest: {
                src: "css/main.css"
            }
        }
    });

    grunt.loadNpmTasks('grunt-autoprefixer');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-contrib-less');
    grunt.loadNpmTasks('grunt-contrib-uglify');

    grunt.registerTask('default', ['uglify', 'watch']);
};
