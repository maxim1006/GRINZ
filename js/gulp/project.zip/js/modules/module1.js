var $ = require('jquery');

console.log('module1');

$('body').css('color', 'green');

module.exports = "exports from module 1";