var module1 = require('./module1');
console.log('module2');
console.log(module1);
